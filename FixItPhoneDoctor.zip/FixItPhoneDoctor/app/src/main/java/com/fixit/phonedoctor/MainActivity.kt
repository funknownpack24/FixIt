package com.fixit.phonedoctor

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FixItApp() }
    }
}

private enum class Screen(val label: String) {
    HOME("Overview"), DIAGNOSTICS("Checks"), GUIDES("Guides"), DEVICE("Device")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FixItApp() {
    val context = LocalContext.current
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selectedGuide by remember { mutableStateOf<Guide?>(null) }
    var refreshKey by remember { mutableIntStateOf(0) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFF1769E0),
            onPrimary = androidx.compose.ui.graphics.Color.White,
            secondary = androidx.compose.ui.graphics.Color(0xFF52647A),
            background = androidx.compose.ui.graphics.Color(0xFFF5F7FB),
            surface = androidx.compose.ui.graphics.Color.White,
            surfaceVariant = androidx.compose.ui.graphics.Color(0xFFEAF0F8)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("FixIt", fontWeight = FontWeight.Bold)
                            Text("Phone Doctor", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    actions = {
                        IconButton(onClick = { refreshKey++ }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh checks")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    Screen.values().forEach { item ->
                        NavigationBarItem(
                            selected = screen == item,
                            onClick = { screen = item; selectedGuide = null },
                            icon = {
                                Icon(
                                    when (item) {
                                        Screen.HOME -> Icons.Default.Dashboard
                                        Screen.DIAGNOSTICS -> Icons.Default.HealthAndSafety
                                        Screen.GUIDES -> Icons.Default.MenuBook
                                        Screen.DEVICE -> Icons.Default.PhoneAndroid
                                    },
                                    contentDescription = item.label
                                )
                            },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                when {
                    selectedGuide != null -> GuideDetail(
                        guide = selectedGuide!!,
                        onBack = { selectedGuide = null }
                    )
                    screen == Screen.HOME -> OverviewScreen(
                        refreshKey = refreshKey,
                        onChecks = { screen = Screen.DIAGNOSTICS },
                        onGuides = { screen = Screen.GUIDES }
                    )
                    screen == Screen.DIAGNOSTICS -> DiagnosticsScreen(refreshKey)
                    screen == Screen.GUIDES -> GuidesScreen(onGuide = { selectedGuide = it })
                    screen == Screen.DEVICE -> DeviceScreen(refreshKey)
                }
            }
        }
    }
}

@Composable
private fun OverviewScreen(refreshKey: Int, onChecks: () -> Unit, onGuides: () -> Unit) {
    val context = LocalContext.current
    val info = remember(refreshKey) { DeviceInfo.read(context) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Let's check your phone", style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                    Text("Practical checks and repair guidance. No account or internet required.",
                        color = MaterialTheme.colorScheme.onPrimary)
                    Button(onClick = onChecks, colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.primary
                    )) { Text("Run device checks") }
                }
            }
        }
        item { SectionTitle("Your device") }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    InfoRow("Manufacturer", info.manufacturer)
                    InfoRow("Model", info.model)
                    InfoRow("Android version", info.androidVersion)
                    InfoRow("Security patch", info.securityPatch)
                }
            }
        }
        item { SectionTitle("Quick status") }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    StatusLine(Icons.Default.BatteryChargingFull, "Battery", info.batterySummary)
                    StatusLine(Icons.Default.Wifi, "Network", info.networkSummary)
                    StatusLine(Icons.Default.Storage, "Storage", info.storageSummary)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onChecks, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.FactCheck, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Checks")
                }
                OutlinedButton(onClick = onGuides, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.MenuBook, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Guides")
                }
            }
        }
        item {
            Text(
                "FixIt only reports information Android makes available. It cannot directly test every hardware component.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DiagnosticsScreen(refreshKey: Int) {
    val context = LocalContext.current
    val checks = remember(refreshKey) { DiagnosticCheck.run(context) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Device checks", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("These checks use Android system data and standard APIs. Results are not a full hardware certification.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        items(checks) { check ->
            Card {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.Top) {
                    Icon(check.icon, contentDescription = null, tint = check.tint)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(check.title, fontWeight = FontWeight.SemiBold)
                        Text(check.result, style = MaterialTheme.typography.bodyMedium)
                        Text(check.detail, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = {
                context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Settings, null)
                Spacer(Modifier.width(8.dp))
                Text("Open battery settings")
            }
        }
    }
}

@Composable
private fun DeviceScreen(refreshKey: Int) {
    val context = LocalContext.current
    val info = remember(refreshKey) { DeviceInfo.read(context) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Device information", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoRow("Manufacturer", info.manufacturer)
                InfoRow("Brand", info.brand)
                InfoRow("Model", info.model)
                InfoRow("Device code", info.device)
                InfoRow("Android release", info.androidVersion)
                InfoRow("API level", info.apiLevel)
                InfoRow("Build fingerprint", info.fingerprint)
                InfoRow("Security patch", info.securityPatch)
                InfoRow("App version", "1.0.0")
                InfoRow("Last refreshed", DateFormat.getDateTimeInstance().format(Date()))
            }
        }
        Text("Device identifiers shown here are local system build details. FixIt does not send them anywhere.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun GuidesScreen(onGuide: (Guide) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Offline troubleshooting", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Choose a symptom for safe checks you can try yourself.",
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(Guides.all) { guide ->
                Card(onClick = { onGuide(guide) }) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(guide.icon, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(guide.title, fontWeight = FontWeight.SemiBold)
                            Text(guide.subtitle, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
    }
}

@Composable
private fun GuideDetail(guide: Guide, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(6.dp)); Text("All guides") }
        Icon(guide.icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        Text(guide.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(guide.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
        guide.steps.forEachIndexed { index, step ->
            Card {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.Top) {
                    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.primaryContainer) {
                        Text("${index + 1}", Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(step, modifier = Modifier.weight(1f))
                }
            }
        }
        if (guide.warning.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Default.Warning, null)
                    Spacer(Modifier.width(8.dp))
                    Text(guide.warning)
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(0.9f))
        Spacer(Modifier.width(12.dp))
        Text(value, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1.1f))
    }
}

@Composable
private fun StatusLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(label, fontWeight = FontWeight.SemiBold)
            Text(value, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private data class DeviceSnapshot(
    val manufacturer: String,
    val brand: String,
    val model: String,
    val device: String,
    val androidVersion: String,
    val apiLevel: String,
    val fingerprint: String,
    val securityPatch: String,
    val batterySummary: String,
    val networkSummary: String,
    val storageSummary: String
)

private object DeviceInfo {
    fun read(context: Context): DeviceSnapshot {
        val battery = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val batteryText = if (level in 0..100) "$level% reported battery level" else "Battery level unavailable"
        val network = networkSummary(context)
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val available = stat.availableBytes
        val storage = "${formatBytes(available)} free of ${formatBytes(total)}"
        return DeviceSnapshot(
            manufacturer = Build.MANUFACTURER.ifBlank { "Unknown" }.replaceFirstChar { it.uppercase() },
            brand = Build.BRAND.ifBlank { "Unknown" },
            model = Build.MODEL.ifBlank { "Unknown" },
            device = Build.DEVICE.ifBlank { "Unknown" },
            androidVersion = Build.VERSION.RELEASE ?: "Unknown",
            apiLevel = Build.VERSION.SDK_INT.toString(),
            fingerprint = Build.FINGERPRINT ?: "Unavailable",
            securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Build.VERSION.SECURITY_PATCH else "Not available",
            batterySummary = batteryText,
            networkSummary = network,
            storageSummary = storage
        )
    }

    private fun networkSummary(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "No active network connection"
        val caps = cm.getNetworkCapabilities(network) ?: return "Network status unavailable"
        val connected = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Connected via Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Connected via mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Connected via Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "Connected via VPN"
            else -> "Connected via another network"
        }
        return if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
            "$connected; Android reports internet access"
        } else {
            "$connected; internet access not confirmed"
        }
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes < 0) return "Unknown"
        val gib = bytes / (1024.0 * 1024.0 * 1024.0)
        return if (gib >= 1) String.format("%.1f GB", gib)
        else String.format("%.0f MB", bytes / (1024.0 * 1024.0))
    }
}

private data class CheckResult(
    val title: String,
    val result: String,
    val detail: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val tint: androidx.compose.ui.graphics.Color
)

private object DiagnosticCheck {
    fun run(context: Context): List<CheckResult> {
        val info = DeviceInfo.read(context)
        val battery = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = battery.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val batteryStatus = when {
            level < 0 -> "Not available"
            level <= 15 -> "Low battery"
            else -> "Battery level reported: $level%"
        }
        val batteryDetail = "Android exposes the current charge percentage. This does not measure battery health or capacity wear."

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = if (network != null) cm.getNetworkCapabilities(network) else null
        val networkResult = when {
            caps == null -> "No active network"
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) -> "Internet access reported"
            else -> "Network connected; internet not confirmed"
        }

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeBytes = stat.availableBytes
        val totalBytes = stat.totalBytes
        val percentFree = if (totalBytes > 0) (freeBytes.toDouble() / totalBytes * 100).roundToInt() else -1
        val storageResult = if (percentFree in 0..9) "Storage space is low" else "${formatPct(percentFree)} available"
        val storageDetail = "${formatBytes(freeBytes)} free out of ${formatBytes(totalBytes)} on the data partition."

        val pm = context.packageManager
        val hasCamera = pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
        val hasTelephony = pm.hasSystemFeature(PackageManager.FEATURE_TELEPHONY)
        val uptime = SystemClock.elapsedRealtime() / 1000
        val uptimeText = "${uptime / 3600} h ${(uptime % 3600) / 60} min since boot"

        val batteryTint = if (level in 0..15) MaterialThemeColor.warning else MaterialThemeColor.good
        val storageTint = if (percentFree in 0..9) MaterialThemeColor.warning else MaterialThemeColor.good
        return listOf(
            CheckResult("Battery charge", batteryStatus, batteryDetail, Icons.Default.BatteryChargingFull, batteryTint),
            CheckResult("Network connectivity", networkResult,
                "Based on Android ConnectivityManager. This does not guarantee every website or app can connect.",
                Icons.Default.Wifi, if (caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true) MaterialThemeColor.good else MaterialThemeColor.neutral),
            CheckResult("Storage space", storageResult, storageDetail, Icons.Default.Storage, storageTint),
            CheckResult("Camera feature", if (hasCamera) "Camera feature reported" else "No camera feature reported",
                "This checks system feature declarations only; it does not take a photo or test image quality.",
                Icons.Default.CameraAlt, MaterialThemeColor.neutral),
            CheckResult("Telephony feature", if (hasTelephony) "Telephony feature reported" else "No telephony feature reported",
                "This reports device capability declarations, not SIM registration, signal strength or call quality.",
                Icons.Default.SignalCellularAlt, MaterialThemeColor.neutral),
            CheckResult("Time since boot", uptimeText,
                "Calculated from Android's elapsed realtime clock. It resets after reboot.",
                Icons.Default.Schedule, MaterialThemeColor.neutral)
        )
    }

    private fun formatPct(value: Int) = if (value >= 0) "$value% free" else "Free space unavailable"
    private fun formatBytes(bytes: Long): String = if (bytes < 1024L * 1024L * 1024L)
        String.format("%.0f MB", bytes / (1024.0 * 1024.0))
    else String.format("%.1f GB", bytes / (1024.0 * 1024.0 * 1024.0))
}

private object MaterialThemeColor {
    val good = androidx.compose.ui.graphics.Color(0xFF18864B)
    val warning = androidx.compose.ui.graphics.Color(0xFFB26A00)
    val neutral = androidx.compose.ui.graphics.Color(0xFF52647A)
}

private data class Guide(
    val title: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val steps: List<String>,
    val warning: String = ""
)

private object Guides {
    val all = listOf(
        Guide(
            "Phone feels slow",
            "Safe steps to improve responsiveness",
            Icons.Default.Speed,
            listOf(
                "Restart the phone and check whether the slowdown continues.",
                "Keep some internal storage free; remove only files you recognise and no longer need.",
                "Close or uninstall apps you do not use. Check Settings → Battery for unusually heavy app use.",
                "Install system and app updates when you have a reliable connection and enough battery.",
                "If one app is slow, update it and clear its cache from Settings → Apps. Avoid clearing its data unless you understand what will be deleted."
            ),
            "Avoid 'RAM booster' or cleaner apps that promise impossible speed improvements. Do not factory-reset without backing up important data."
        ),
        Guide(
            "Battery drains quickly",
            "Check settings before replacing parts",
            Icons.Default.BatteryAlert,
            listOf(
                "Open Settings → Battery and review which apps use the most power.",
                "Lower screen brightness and shorten screen timeout if practical.",
                "Turn off hotspot, Bluetooth or location when you do not need them.",
                "Restart the phone and check whether drain persists after a normal use period.",
                "Check for system updates and app updates."
            ),
            "Stop charging and seek qualified repair help if the phone becomes unusually hot, swells, smells strange or shows physical battery damage. This app cannot measure battery health."
        ),
        Guide(
            "Phone will not charge",
            "Basic checks for charging problems",
            Icons.Default.BatteryChargingFull,
            listOf(
                "Try a known-good, compatible wall adapter and cable.",
                "Test another wall outlet.",
                "Inspect the charging port with a light. Do not insert metal objects or liquids.",
                "Restart the phone and check whether the charging indicator appears.",
                "If possible, compare with a known-good compatible charger."
            ),
            "Do not continue charging if the device, cable or adapter is damaged, wet or unusually hot. Port cleaning and internal repair should be handled safely by a qualified person."
        ),
        Guide(
            "Wi-Fi or mobile data not working",
            "Separate connection issues from internet issues",
            Icons.Default.Wifi,
            listOf(
                "Check whether Airplane mode is off and Wi-Fi or mobile data is enabled.",
                "Toggle the affected connection off, wait a few seconds, then turn it on again.",
                "For Wi-Fi, check whether another device can use the same network.",
                "For mobile data, check your plan, coverage and preferred SIM for data.",
                "Restart the phone. If only one app fails, check that app's permissions and service status."
            ),
            "A connected Wi-Fi icon does not always mean the network has internet access. Network resets may remove saved Wi-Fi passwords."
        ),
        Guide(
            "Phone is overheating",
            "Reduce load and let the device cool safely",
            Icons.Default.Thermostat,
            listOf(
                "Stop demanding games, navigation or video recording temporarily.",
                "Unplug the charger if the device is unusually hot.",
                "Move the phone out of direct sunlight and remove a thick case if safe to do so.",
                "Let it cool naturally in a dry, ventilated place.",
                "When cool, review battery usage and update apps if appropriate."
            ),
            "Never put a hot phone in a fridge or freezer. If heat persists at idle, or the battery looks swollen or damaged, stop using it and seek qualified service."
        ),
        Guide(
            "App keeps crashing",
            "Troubleshoot one app at a time",
            Icons.Default.BugReport,
            listOf(
                "Restart the phone.",
                "Update the affected app from its trusted source.",
                "Check that the phone has enough free storage.",
                "Open Settings → Apps → the affected app → Storage and try Clear cache if available.",
                "If the issue continues, check the developer's support information before reinstalling."
            ),
            "Clearing app data or reinstalling may delete local information. Back up anything important first, and never install unknown APKs just to fix a crash."
        )
    )
}
