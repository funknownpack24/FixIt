# FixIt Phone Doctor

An offline-first native Android app built with Kotlin and Jetpack Compose. It displays device information, runs checks using Android APIs, and provides offline troubleshooting guides.

## Features

- Device information: manufacturer, brand, model, device code, Android release, API level, build fingerprint, and security patch.
- Supported checks:
  - Battery charge percentage (not battery health).
  - Active network and Android's validated-internet capability.
  - Free and total space on the data partition.
  - Camera and telephony feature declarations.
  - Time elapsed since boot.
- Offline troubleshooting guides for slow performance, battery drain, charging, network problems, overheating, and app crashes.
- No account, analytics SDK, backend, or runtime permissions required.
- Material 3 UI and English-only content.

## Important diagnostic limits

Android does not expose every hardware measurement to ordinary apps. FixIt does not claim to test battery wear, camera quality, microphone quality, speaker output, SIM registration, cellular signal quality, charging current, or internal component health. Feature declarations are not a full hardware test. Network connectivity does not guarantee that every service is reachable.

## Requirements

- Android Studio with Android SDK Platform 35 installed.
- JDK 17.
- Internet connection for the first Gradle dependency download. The app itself works offline after installation.
- Minimum Android version: Android 8.0 (API 26).

## Build in Android Studio

1. Extract the ZIP.
2. Open Android Studio and choose **Open**.
3. Select the extracted `FixItPhoneDoctor` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync to complete. The first sync downloads Android Gradle Plugin, Kotlin and AndroidX dependencies.
5. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. Android Studio will show a link to the generated APK. Usually it is under `app/build/outputs/apk/debug/`.

### Command-line build

With JDK 17 and Android SDK installed:

```bash
gradle assembleDebug
```

If you add the Gradle wrapper from Android Studio, use:

```bash
./gradlew assembleDebug
```

On Windows:

```bat
gradlew.bat assembleDebug
```

This ZIP intentionally does not include a Gradle wrapper JAR or a prebuilt APK. Generate the wrapper using Android Studio/Gradle in your environment, and build the APK there.

## Upload to GitHub

1. Create a new repository on GitHub, for example `FixItPhoneDoctor`.
2. Extract this ZIP.
3. In the repository page, choose **Add file → Upload files** and upload the extracted project files/folders, or use Git:

```bash
git init
git add .
git commit -m "Initial FixIt Phone Doctor app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/FixItPhoneDoctor.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Never commit signing keys, passwords, or private credentials.

## Project structure

```text
FixItPhoneDoctor/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/fixit/phonedoctor/MainActivity.kt
├── build.gradle.kts
├── gradle.properties
├── settings.gradle.kts
└── README.md
```

## Privacy

The app reads system information locally and does not send it to a server. The build fingerprint may contain vendor/build details; it stays on-device and is shown only on the Device screen.

## Version

1.0.0 — starter project.
